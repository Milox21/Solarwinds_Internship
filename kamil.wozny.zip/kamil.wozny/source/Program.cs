﻿using swi;
using System.Text.Json;

string fileNname = AppContext.BaseDirectory + "input.json";
if (File.Exists(fileNname))
{
    string json = File.ReadAllText(AppContext.BaseDirectory + "input.json");
    Dictionary<string, EquationObject> dicEquations = JsonSerializer.Deserialize<Dictionary<string, EquationObject>>(json);
    List<EquationObject> listEquations = new();

    foreach (var equation in dicEquations)
    {
        equation.Value.Name = equation.Key;
        equation.Value.Calculate();

        listEquations.Add(equation.Value);
    }

    listEquations = listEquations.OrderBy(item => item.CalculatedValue).ToList();

    string fileOut = "output.txt";

    using (StreamWriter writer = new StreamWriter(fileOut))
    {
        foreach (var equation in listEquations)
        {
            writer.WriteLine(equation.Name + ": " + equation.CalculatedValue);
        }
    }
}



