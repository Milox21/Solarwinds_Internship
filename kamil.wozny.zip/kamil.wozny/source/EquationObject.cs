﻿using System.Text.Json.Serialization;

namespace swi
{
    public class EquationObject
    {
        [JsonIgnore]
        public string Name { set; get; }

        [JsonPropertyName("operator")]
        public string Operator { set; get; }

        [JsonPropertyName("value1")]
        public int Value1 { set; get; }

        [JsonPropertyName("value2")]
        public int Value2 { set; get; }

        [JsonIgnore]
        public double CalculatedValue { set; get; }

        public void Calculate()
        {
            switch(Operator)
            {
                case "add":
                    CalculatedValue = Value1 + Value2;
                    break;
                case "sqrt":
                    CalculatedValue = Math.Sqrt(Value1);
                    break;
                case "sub":
                    CalculatedValue = Value1 - Value2;
                    break;
                case "mul":
                    CalculatedValue = Value1 * Value2;
                    break;
            }
        }
    }
}
